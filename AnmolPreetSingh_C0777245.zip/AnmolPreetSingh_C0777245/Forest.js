var Tiger = require('./Tiger');
var Lion = require('./Lion');
class Forest{
     
    static lions = new Array();
  
    static tigers = new Array();


    static  NumberOfLIONWinners = 0;
    static  NumberOfTigerWinners = 0;

    static lionsArray = new Array();
    static tigersArray = new Array();
    
    static totalLionWinners = 0;
    static totalTigerWinners = 0;

    static totalLionWinnerArray = new Array();
    static totalTigerWinnerArray = new Array();

   static startGame(){
     
        for(var i = 0; i<20; i++){
            Forest.lions[i] = new Lion();
            Forest.tigers[i] = new Tiger();
        }
    }

    static runCompetition(){
       Forest.NumberOfLIONWinners = 0;
       Forest.NumberOfTigerWinners = 0;
       for(var i = 0; i<20; i++){
           if((Forest.lions[i].getStrength() > (Forest.tigers[i].getStrength()))){
               Forest.NumberOfLIONWinners++;
           }else{
               Forest.NumberOfTigerWinners++;
           }
       }

       if(Forest.NumberOfLIONWinners > Forest.NumberOfTigerWinners ){
           var a = Forest.NumberOfLIONWinners;
           var b = Forest.NumberOfTigerWinners;
           Forest.NumberOfLIONWinners = b;
           Forest.NumberOfTigerWinners = a
       }

       if(Forest.NumberOfLIONWinners == Forest.NumberOfTigerWinners){
           Forest.NumberOfLIONWinners -= 2;
           Forest.NumberOfTigerWinners +=2;
       }
    }

    static declareWinner(i){
        Forest.lionsArray[i] = Forest.NumberOfLIONWinners;
        Forest.tigersArray[i] = Forest.NumberOfTigerWinners; 

        console.log("Lions: "+Forest.NumberOfLIONWinners);
        console.log("Tigers: " + Forest.NumberOfTigerWinners);

        Forest.totalLionWinners += Forest.NumberOfLIONWinners;
        Forest.totalTigerWinners += Forest.NumberOfTigerWinners

        if(i == 20){

        Forest.totalTigerWinnerArray[0] = "Total Tiger Winners: ";
        Forest.totalTigerWinnerArray[1] = Forest.totalTigerWinners;

        Forest.totalLionWinnerArray[0] = "Total Lion Winners: ";
        Forest.totalLionWinnerArray[1] = Forest.totalLionWinners;
        
        var rows = [Forest.tigersArray,Forest.lionsArray, Forest.totalTigerWinnerArray, Forest.totalLionWinnerArray];

           let csvContent = "";
       
       rows.forEach(function(rowArray) {
           let row = rowArray.join(",");
           csvContent += row + "\n";
       });

       // var encodedUri = encodeURI(csvContent);
            var fs = require('fs');
            fs.writeFile("solution.csv", csvContent, function(err) {
                if(err) {
                    return console.log(err);
                }

           console.log("For output, please open 'solution.csv'")
       });
        }
    }
}
module.exports = Forest;