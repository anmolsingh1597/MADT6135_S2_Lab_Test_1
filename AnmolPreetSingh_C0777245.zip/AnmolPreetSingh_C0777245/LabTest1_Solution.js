//Name: Anmol Preet Singh Chhabra
//Student id: C0777245
//Course: MADT_6135 S2
//Date Submitted: 16 April 2021

// 'use strict'

var Forest = require('./Forest');

class LabTest1_Solution {
    constructor() {
        Forest.lionsArray[0] = "Lions Winner: "
        Forest.tigersArray[0] = "Tiger Winner: "
        for(var i = 1; i < 21; i++){
            Forest.startGame();
            Forest.runCompetition();
            Forest.declareWinner(i);
        }
    }
 }

 
 
let comp = new LabTest1_Solution();

