var Feline = require('./Feline');
class Tiger extends Feline {
    constructor() {
        super()
        this.setStrength()
     }
     setStrength(){
        this.strength = Math.floor(Math.random() * 100); 
    }
 }
 module.exports = Tiger;