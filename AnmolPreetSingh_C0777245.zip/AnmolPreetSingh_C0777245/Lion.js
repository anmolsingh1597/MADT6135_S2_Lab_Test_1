var Feline = require('./Feline');

class Lion extends Feline {
    constructor() {
        super()
        this.setStrength()
    }

    setStrength(){
        this.strength = Math.floor(Math.random() * 100); 
    }
 }
 module.exports = Lion;