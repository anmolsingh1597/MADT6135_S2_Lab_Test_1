class Feline {

    // var strength;
    
        constructor() {
            this.strength = Math.floor(Math.random() * 100); 
        }
    
        getStrength(){
            return this.strength;
        }
     }
     module.exports = Feline;

    